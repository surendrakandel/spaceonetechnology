# Usecase UI

A standalone component library for marketing sites, service workflows, directories, dashboards, and client portals. Built with Svelte 5, Alpine.js, Tailwind CSS 4, daisyUI 5, Lucide, and Motion. The four reference projects supplied use cases only; this library has no dependency on them.

## Start

```sh
nvm use
pnpm install
pnpm build
pnpm dev
```

Open http://127.0.0.1:5177. Every one of the 98 component pages has an interactive demo, color and appearance controls, syntax-highlighted Svelte and HTML examples, installation guidance, and typed source.

## Choose a format

- **Svelte package:** named imports such as `Button`, `Card`, and `CardBody`. No compound namespaces. Import `@usecase-ui/svelte/styles.css` once, or use editable source with Tailwind.
- **HTML + Alpine.js:** 76 examples use native HTML with prebuilt CSS, Alpine.js, and Motion. Marketing content, cards, forms, images, and controls share their layout and typography with Svelte. Native disclosures and form controls retain browser behavior.
- **Optional web components:** 22 complex workflow examples still use lazy-loaded custom elements alongside Alpine. Their Svelte runtime is prebuilt; receiving projects do not need a Svelte build. Copy the full browser asset folder, including its chunks. The HTML example clearly identifies its runtime.

```sh
# Run from this workspace; destination can be another project.
node packages/cli/bin/usecase-ui.mjs add card pricing-card --cwd /path/to/svelte-app
node packages/cli/bin/usecase-ui.mjs add card accordion --format html --cwd /path/to/website
```

```svelte
<script>
	import { Card, CardBody, CardTitle, Button } from '@usecase-ui/svelte';
	import '@usecase-ui/svelte/styles.css';
</script>

<Card>
	<CardBody>
		<CardTitle>Project overview</CardTitle>
		<Button animated={false}>Continue</Button>
	</CardBody>
</Card>
```

HTML examples contain no Liquid. They can be placed in server-rendered templates and adapted to the host's asset URLs. Complex custom elements require JavaScript; native HTML controls remain usable without it. Frontend components expose callbacks/events; the consuming app owns payments, authentication, storage, and validation.

## Theme and motion

Use daisyUI's `--color-primary`, `--color-primary-content`, and `--color-base-*` tokens. Shared `--font-sans`, `--text-*`, `--spacing`, `--radius-field`, `--radius-box`, `--container-width`, and `--content-width` control the layout. There are 56 themes: 35 daisyUI presets, five curated palettes, and eight shadcn-svelte palettes with light/dark variants. No shadcn component dependency is used. The default container is 1600px; reading content stays narrower.

Use `/themes` for the gallery, `/settings` for schema-driven configuration, and `/tokens` for the full 146-token studio. Theme → section → element settings inherit, with explicit local overrides. See [themes](docs/themes.md), [settings](docs/settings.md), [typography](docs/typography.md), [internationalization](docs/internationalization.md), and [SEO](docs/seo.md).

Animation defaults to `inherit`; `none` disables the local effect. Set `animated={false}` on a Svelte component or `data-motion="off"` on an HTML element or ancestor. Motion respects `prefers-reduced-motion`. Entrances are limited to relevant sections; buttons and disclosures use interaction feedback. See [motion guidance](docs/motion.md).

## Packages

| Package               | Purpose                                                               |
| --------------------- | --------------------------------------------------------------------- |
| `@usecase-ui/svelte`  | Typed, tree-shakable Svelte source plus prebuilt styles               |
| `@usecase-ui/browser` | Native HTML examples, enhancement module, and optional web components |
| `@usecase-ui/cli`     | Offline component installer with conflict and path protection         |
| `apps/docs`           | SvelteKit component explorer using the Cloudflare adapter             |

Names are provisional and **not published or reserved on npm**. `pnpm release:check` builds and checks installable tarballs. See [publishing](docs/publishing.md), [integration](docs/integration.md), [source inventory](docs/source-use-cases.md), and [Cloudflare](docs/cloudflare.md).

## Verification

```sh
pnpm check
pnpm build
pnpm test
pnpm test:e2e
node scripts/check-packages.mjs
node scripts/check-compatibility.mjs
```

The compatibility script installs isolated SvelteKit consumers; it does not change the workspace lockfile. The library targets modern browsers with ES modules, native dialog, and custom-element support.

The official component comparison and remaining implementation gaps are recorded in [component coverage](docs/component-coverage.md).

## Design assets

Browse `/assets` for curated Flowbite illustrations, Notionists avatars, and the existing Lucide icon family. The gallery includes light/dark previews, SVG and transparent PNG downloads, highlighted usage, and a complete asset pack. Assets are local and optional, with source records and redistribution notices. See [asset guidance](docs/assets.md).
